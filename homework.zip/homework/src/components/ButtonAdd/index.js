import React, { Component } from "react";
import "./buttonadd";
import {Button} from 'react-bootstrap';

export default class ButtonAdd extends Component {
    render(){
        return(
            <div className="bottom-right">
                <Button>
                    <i className="fas fa-plus-circle"></i>
                </Button>
            </div>
        );
    }
}
