import React from "react";
import "./facebook.css";
const Facebook = () => {
    return <span><i onClick={()=>window.location.assign("https://www.facebook.com/")} class="fab fa-facebook-f"></i></span>;
};
export default Facebook;