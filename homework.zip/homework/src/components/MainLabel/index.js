import MainLabel from './mainlabel';


export default MainLabel