import React, { Component } from "react";
import { Row } from "react-bootstrap";
import "./mainlabel.css";
import {Alert} from 'react-bootstrap';
export default class MainLabel extends Component
{
    render()
    {
      
        return(
            <Row className="rs">
                <Alert className="inf">All contacts: {this.props.countOfCards}, number of favourite: {this.props.countOfFavouriteCards}</Alert>
            </Row>
        );
        
    }
}