import React, { Component } from "react";
import "./maininfo.css";
import {Row} from "react-bootstrap";
import {Col} from "react-bootstrap";
import {Image} from "react-bootstrap";

export default class MainInfo extends Component
{
    render()
    {
        
        let path = `https://robohash.org/${this.props.name}?set=set4`
        return(
                 <Row>
                    <Col sm={4}>
                       <Image className="profImg" src={path} roundedCircle/>
                    </Col>
                    <Col sm={8} >
                        <Row className="infoname">Name: {this.props.name}</Row>
                        <Row className="infophone">Phone: {this.props.phone}</Row>
                        <Row className="infoemail">Email: {this.props.email}</Row>

                    </Col>
                 </Row>
        );
    }
}