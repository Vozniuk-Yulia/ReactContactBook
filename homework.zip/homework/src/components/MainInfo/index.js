import MainInfo from './maininfo';
export default MainInfo;