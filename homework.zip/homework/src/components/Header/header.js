import Button from "react-bootstrap/Button";
import { Component } from "react";
import FormControl from "react-bootstrap/FormControl";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";


import InputGroup from "react-bootstrap/InputGroup";
export default class Header extends Component
{
    state = {
        query: "",
      };
    
      onSearchChanged = (e) => {
        const { onSearch } = this.props;
        onSearch(e.target.value);
        this.setState({
          query: e.target.value,
        });
      };
    render()
    {
        return(
            <Row>
              <Col sm={8}>
              <InputGroup className="mb-3 mt-3 ">
        <FormControl onChange={this.onSearchChanged} placeholder="Search" />

        <InputGroup.Append>
          <Button variant="outline-secondary" className="btn">
            {" "}
            Search{" "}
          </Button>
        </InputGroup.Append>
      </InputGroup>
              </Col>
              <Col sm={4}>
                  <div className="fav"> 
                  <i className="far fa-star ot"></i>
                  </div>
              </Col>
            </Row>
        );
        
    }
}