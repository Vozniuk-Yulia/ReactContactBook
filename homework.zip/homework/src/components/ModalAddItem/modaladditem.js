import React, { Component } from "react";
import "./modaladditem.css";
import {Button} from "react-bootstrap";
import {Modal} from "react-bootstrap";
import {Form} from "react-bootstrap";

export default class ModalAddItem extends Component
{
    state = {
        name:'',
        phone: '',
        email:'',
        image: '',
        isOpened: false,
    };
   
    openModalWindow=()=>
    {
        this.setState({
            name:"",
            phone: "",
            email:"",
            image: "",
            isOpened: true,
        })
    }
    closeModalWindow=()=>
    {
        this.setState({isOpened:false});
    }
  
    
    changeName=(e)=>
    {
        this.setState({name:e.target.value});
    }
    changePhone=(e)=>
    {
        this.setState({phone:e.target.value});
    }
    changeEmail=(e)=>
    {
        this.setState({email:e.target.value});
    }
    changeImage=(e)=>
    {
        this.setState({image:e.target.value});
    }
    
    render()
    {
        const { onSubmitAddForm } = this.props;
        const { isOpened, name, phone, email, image} = this.state;

        return(<>
            <Button>
              <i onClick={this.openModalWindow} className="fas fa-plus-circle"> </i>
            </Button>
            <Modal show={isOpened} onHide={this.closeModalWindow}>
            <Modal.Header closeButton>
               <Modal.Title>New contact</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group>
                        <Form.Control onChange={(e)=>this.changeName(e)} value={name} className="mt-3" type="text" placeholder="Enter name: "></Form.Control>
                        <Form.Control onChange={(e)=>this.changePhone(e)} value={phone} className="mt-3" type="text" placeholder="Enter phone: "></Form.Control>
                        <Form.Control onChange={(e)=>this.changeEmail(e)} value={email} className="mt-3" type="email" placeholder="Enter email: "></Form.Control>
                        <Form.Control onChange={(e)=>this.changeImage(e)} value={image} className="mt-3" type="text" placeholder="Enter url of image: "></Form.Control>
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={this.closeModalWindow}>
                Cancel
              </Button>
              <Button variant="primary" onClick={() => {
                        this.closeModalWindow();
                        onSubmitAddForm(this.state);
                    }}>
                        OK
                    </Button>
            </Modal.Footer>
            </Modal>
        </>);
    }
}

