import React, { Component } from "react";
import "./mainwindow.css";
import { Container}from 'react-bootstrap';
import {ListGroup} from 'react-bootstrap';
import {Col} from 'react-bootstrap';
import Header from "../Header";
import MainLabel from "../MainLabel";
import MainCard from "../MainCard";
import { Button } from "react-bootstrap";
import ModalAddItem from "../ModalAddItem";


export default class MainWindow extends Component
{
  state = {
    query: "",
    data: [
        {
            id: 1,
            name: "Vadim",
            phone: "4474183530",
            email:"vaadyaa@gmail.com",
            favourite: false,
            social: {
                faceb: "https://www.facebook.com",
                instag: "https://instagram.com",
            },
        },
        {
            id: 2,
            name: "Olya",
            phone: "4474183513",
            email:"olichka@ukr.net",
            favourite: false,
            social: {
              faceb: "https://www.facebook.com",
              instag: "https://instagram.com",
              twitt: "https://twitter.com",
            },
        },
        {
            id: 3,
            name: "Denis",
            phone: "4475206434",
            email:"denya@gmail.com",
            favourite: false,
            social: {
              twitt: "https://twitter.com"
            },
        },
    ],
};


findElementByIndex = (id) => {
  return this.state.data.findIndex((x) => x.id === id);
};
onFavouriteChange = (id) => {
  var index = this.findElementByIndex(id);
  this.setState(({ data }) => {
      let newEl = data[index];
      newEl.favourite = !newEl.favourite;

      let before = data.slice(0, index);
      let after = data.slice(index + 1);

      return {
          data: [...before, newEl, ...after],
      };
  });
};
onDelete = (id) => {
  let index = this.findElementByIndex(id);

  this.setState(({ data }) => {
      return {
          data: [...data.slice(0, index), ...data.slice(index + 1)],
      };
  });
};
onSubmitAddForm = (item) => {

  this.setState(({data}) => {

      const contact = data[data.length - 1];

      const new_id = (contact !== undefined) ? contact.id + 1 : 1;

      const newArray = [

          ...data,
          {
              id: new_id,
              name: item.name,
              phone: item.phone,
              email: item.email,
              image: item.image
          }
      ];

      return {
          data: newArray
      }
  });
};
onFilter = () => {
  let users = this.state.data;
  if (this.state.query === "") {
    return this.getUsers(users);
  }

  return this.getUsers(
    users.filter((x) => {
      return x.name.toLowerCase().includes(this.state.query.toLowerCase());
    })
  );
};
onQueryChanged = (newQuery) =>{
  this.setState({
      query: newQuery
  });
};

getNew=()=>
{
  let users = this.state.data;

  return this.getUsers(
    users.sort((a, b) => 
    {return a.name.toLowerCase() < b.name.toLowerCase()})
  );

};
getUsers = (data) => {
  return data.map((el) => {
    return (
      <MainCard
        id={el.id}
        key={el.id}
        name={el.name}
        email={el.email}
        phone={el.phone}
        social={el.social}
        onDelete={() => this.onDelete(el.id)}
        onFavouriteChange={() => this.onFavouriteChange(el.id)}
        favourite={el.favourite}
      />
    );
  });
};
    render()
    {        
      
        let countOfCards=this.state.data.length;   
        let countOfFavouriteCards=0;

        const { data } = this.state;
       

        return(
            <Container >
        <Col>
        <Header onSearch ={this.onQueryChanged} />
          <MainLabel countOfCards={countOfCards} countOfFavouriteCards={countOfFavouriteCards}></MainLabel>
          <ListGroup >
                            
          <div className="row l">{this.onFilter()}</div>

                          
                         
          </ListGroup>
          <Button onClick={this.getNew()}>Sort</Button>


        </Col>
        <div className="bottom-right">
        <ModalAddItem onSubmitAddForm={this.onSubmitAddForm}></ModalAddItem>
        </div>

      </Container>
      
        );
       
    }
}