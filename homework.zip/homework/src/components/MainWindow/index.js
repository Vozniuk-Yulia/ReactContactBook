import MainWindow from './mainwindow';

export default MainWindow;