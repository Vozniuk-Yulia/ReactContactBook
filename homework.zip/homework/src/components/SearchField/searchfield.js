import React from "react";
import {Form} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import {FormControl} from 'react-bootstrap';
import "./searchfield.css";

export default class SearchField extends Comment
{
  state = {
    query: "",
  };
  
  onSearchChanged = (e) => {
    const { onSearch } = this.props;
    onSearch(e.target.value);
    this.setState({
      query: e.target.value,
    })};
    render()
    {
      return(
        <Form inline>
        <FormControl onSearch={this.onSearchChanged}  type="text" placeholder="Search field" className=" mr-sm-2" />
        <Button type="submit">Search</Button>
    </Form>
      );
    }
}

