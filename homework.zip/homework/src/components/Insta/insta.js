import React from "react";
import "./insta.css";
const Insta = () => {
    return <span><i onClick={()=>window.location.assign("https://www.instagram.com/")} class="fab fa-instagram"></i></span>;
};
export default Insta;