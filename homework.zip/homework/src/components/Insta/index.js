import Insta from './insta';
export default Insta;