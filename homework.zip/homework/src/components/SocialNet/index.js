import SocialNet from './socialnet';

export default SocialNet;