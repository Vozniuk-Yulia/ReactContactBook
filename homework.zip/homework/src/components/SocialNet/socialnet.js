import React, { Component } from "react";
import {Row} from 'react-bootstrap';
import Insta from "../Insta";
import Facebook from "../Facebook";
import Twitter from "../Twitter";
import "./socialnet.css";
export default class SocialNet extends Component
{
   
    render()
    {
       
        return(
            <Row className="rn">
              
              <Insta></Insta>
              <Facebook></Facebook>
              <Twitter>
              </Twitter>
            </Row>
        );
        
    }
}