import React from "react";
import "./twitter.css";
const Twitter = () => {
    return <span><i class="fab fa-twitter" onClick={()=>window.location.assign("https://twitter.com/")}></i></span>;
};
export default Twitter;