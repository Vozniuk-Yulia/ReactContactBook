import React, { Component } from "react";
import "./maincard.css";
import {Container, ListGroup} from "react-bootstrap";
import {Card} from "react-bootstrap";
import MainInfo from "../MainInfo";
 import SocialNet from "../SocialNet";

export default class MainCard extends Component
{
    state = {
        selected: false
    };

    onSelect = (block) => {
        this.setState(({ selected }) => {
            return {
                selected: !selected
            }
        })
    };

    render(){
       
      const className =
      this.props.favourite === true ? "fas fa-star" : "far fa-star";
      const name = this.state.selected ? "card border-dark" : "";
      
        return(
        <ListGroup onClick={this.onSelect} className={name}>
            <Container className="contain">
                    <Card className="card">
                        <Card.Header  className="del">
                        <div >
                         <i onClick={this.props.onDelete} className="fas fa-times"></i>
                         </div>
                        </Card.Header>
                        <Card.Body>
                          <MainInfo name={this.props.name} phone={this.props.phone} email={this.props.email}></MainInfo>
                          <SocialNet></SocialNet>
                           <div><i onClick={this.props.onFavouriteChange} className={className} ></i></div>
                        </Card.Body >
                    </Card>
            </Container>
        
        </ListGroup>

        );
    }
}