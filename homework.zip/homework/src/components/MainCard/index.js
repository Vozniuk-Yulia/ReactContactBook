import MainCard from './maincard';
export default MainCard;