import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import ReactDOM from 'react-dom';
import './index.css';

import MainWindow from "./components/MainWindow";
export default class App extends Component
{
  render() {
    return (
      <MainWindow></MainWindow>
    );
   
  }
}
ReactDOM.render(<App />, document.getElementById("root"));

